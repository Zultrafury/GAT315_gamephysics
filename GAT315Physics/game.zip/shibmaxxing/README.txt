thanks for unzipping this
esc to quit
dont @ me if the game is bs for no reason :p